document.addEventListener('DOMContentLoaded', () => {
  // Get stats from storage
  chrome.storage.local.get(['maliciousCount', 'warningsCount'], (result) => {
    document.getElementById('maliciousCount').textContent = 
      result.maliciousCount || 0;
    document.getElementById('warningsCount').textContent = 
      result.warningsCount || 0;
  });

  // Check current tab status
  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    const tab = tabs[0];
    if (tab.url) {
      chrome.runtime.sendMessage(
        {action: "checkUrl", url: tab.url},
        (response) => {
          const statusEl = document.getElementById('status');
          if (response.isMalicious) {
            statusEl.innerHTML = '❌ <span>This page is malicious!</span>';
          } else if (response.isSuspicious) {
            statusEl.innerHTML = '⚠️ <span>This page looks suspicious</span>';
          } else {
            statusEl.innerHTML = '✅ <span>This page appears safe</span>';
          }
        }
      );
    }
  });

  // Options button
  document.getElementById('options').addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });
});
