// Analyze page content for phishing indicators
function analyzePage() {
  const textContent = document.body.innerText;
  
  chrome.runtime.sendMessage(
    { action: "checkPhishing", text: textContent },
    (response) => {
      if (response.isSuspicious) {
        showWarningBanner();
      }
    }
  );
}

function showWarningBanner() {
  const banner = document.createElement('div');
  banner.style.position = 'fixed';
  banner.style.top = '0';
  banner.style.left = '0';
  banner.style.width = '100%';
  banner.style.backgroundColor = '#ff4444';
  banner.style.color = 'white';
  banner.style.padding = '10px';
  banner.style.zIndex = '9999';
  banner.style.textAlign = 'center';
  banner.innerHTML = `
    ⚠️ Warning: This page contains characteristics commonly associated with phishing sites.
    <button id="closeWarning" style="margin-left: 10px; background: white; border: none; border-radius: 3px; padding: 2px 5px;">X</button>
  `;
  
  document.body.prepend(banner);
  
  document.getElementById('closeWarning').addEventListener('click', () => {
    banner.remove();
  });
}

// Run analysis when page loads
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', analyzePage);
} else {
  analyzePage();
}
