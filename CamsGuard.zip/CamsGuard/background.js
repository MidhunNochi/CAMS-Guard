// Database of known malicious URLs (in a real app, this would be fetched from a server)
const maliciousDomains = new Set([
  'evilphishingsite.com',
  'malwaredownload.example',
  'fakebanklogin.net'
]);

// Check URLs against our database
function isMaliciousUrl(url) {
  try {
    const domain = new URL(url).hostname;
    return maliciousDomains.has(domain);
  } catch {
    return false;
  }
}

// Listen for navigation requests
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    if (isMaliciousUrl(details.url)) {
      return { redirectUrl: chrome.runtime.getURL('warning.html') + '?url=' + encodeURIComponent(details.url) };
    }
  },
  { urls: ["<all_urls>"] },
  ["blocking"]
);

// Check page content for phishing indicators
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "checkPhishing") {
    const phishingKeywords = [
      'login', 'password', 'account', 'verify', 'bank', 
      'credit card', 'social security', 'urgent'
    ];
    const text = request.text.toLowerCase();
    const score = phishingKeywords.reduce((acc, keyword) => 
      acc + (text.includes(keyword) ? 1 : 0), 0);
    
    sendResponse({ isSuspicious: score > 3 });
  }
});
